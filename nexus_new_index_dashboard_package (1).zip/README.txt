NEXUS // D2C — New Landing + Dashboard Package
================================================

Files:
- index.html       — new NEXUS landing page supplied by the user, with demo login wired in
- dashboard.html   — NEXUS autonomous decision engine dashboard

DEMO LOGIN
----------
Email:    demo@nexus.local
Password: Nexus123!

FLOW
----
1. Open index.html.
2. Click any "Open dashboard" / "Approve" action.
3. The NEXUS login modal appears.
4. Enter the demo credentials above.
5. Successful authentication stores nexus_auth=demo in localStorage and opens dashboard.html.
6. dashboard.html protects itself with the same demo auth guard.
7. Dashboard "Log out" clears the demo auth state and returns to index.html.

IMPORTANT
---------
This is a front-end demo authentication flow only. Credentials and auth state are stored client-side and are NOT secure production authentication.
For production, replace this with a server-side/session-based authentication system.
